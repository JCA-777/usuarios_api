class AdministradorUsuarios {
    constructor() {
        this.usuarios = [];
        this.url = "https://jsonplaceholder.typicode.com/users";

        const xhr = new XMLHttpRequest();

        xhr.open("GET", this.url, true);

        xhr.onload = () => {
            if (xhr.status === 200) {
                this.usuarios = JSON.parse(xhr.responseText);
                console.log("Datos cargados correctamente.");
                this.mostrar("Datos cargados correctamente. Ya puede usar los botones.");
            } else {
                console.log("Error al cargar los datos.");
                this.mostrar("Error al cargar los datos.");
            }
        };

        xhr.onerror = () => {
            console.log("Error de conexión.");
            this.mostrar("Error de conexión.");
        };

        xhr.send();
    }

    mostrar(mensaje) {
        document.getElementById("resultado").textContent = mensaje;
        console.log(mensaje);
    }

    listarNombres() {
        let nombres = this.usuarios.map(usuario => usuario.name);

        console.log("Nombres de usuarios:");
        console.log(nombres);

        this.mostrar("Nombres de usuarios:\n" + nombres.join("\n"));
    }

    buscarInfoBasica() {
        let nombre = prompt("Ingrese el nombre del usuario:");

        let usuario = this.usuarios.find(u =>
            u.name.toLowerCase() === nombre.toLowerCase()
        );

        if (usuario) {
            let mensaje =
                "Información básica:\n" +
                "Username: " + usuario.username + "\n" +
                "Correo: " + usuario.email;

            this.mostrar(mensaje);
        } else {
            this.mostrar("Usuario no encontrado.");
        }
    }

    buscarDireccion() {
        let nombre = prompt("Ingrese el nombre del usuario:");

        let usuario = this.usuarios.find(u =>
            u.name.toLowerCase() === nombre.toLowerCase()
        );

        if (usuario) {
            let direccion = usuario.address;

            let mensaje =
                "Dirección del usuario:\n" +
                "Calle: " + direccion.street + "\n" +
                "Suite: " + direccion.suite + "\n" +
                "Ciudad: " + direccion.city + "\n" +
                "Código postal: " + direccion.zipcode + "\n" +
                "Latitud: " + direccion.geo.lat + "\n" +
                "Longitud: " + direccion.geo.lng;

            this.mostrar(mensaje);
        } else {
            this.mostrar("Usuario no encontrado.");
        }
    }

    buscarInfoAvanzada() {
        let nombre = prompt("Ingrese el nombre del usuario:");

        let usuario = this.usuarios.find(u =>
            u.name.toLowerCase() === nombre.toLowerCase()
        );

        if (usuario) {
            let mensaje =
                "Información avanzada:\n" +
                "Teléfono: " + usuario.phone + "\n" +
                "Sitio web: " + usuario.website + "\n" +
                "Compañía: " + usuario.company.name + "\n" +
                "Frase de la compañía: " + usuario.company.catchPhrase + "\n" +
                "BS: " + usuario.company.bs;

            this.mostrar(mensaje);
        } else {
            this.mostrar("Usuario no encontrado.");
        }
    }

    listarCompanias() {
        let companias = this.usuarios.map(usuario => ({
            nombre: usuario.company.name,
            frase: usuario.company.catchPhrase
        }));

        let mensaje = "Compañías:\n";

        companias.forEach(compania => {
            mensaje += "\nNombre: " + compania.nombre;
            mensaje += "\nCatchphrase: " + compania.frase + "\n";
        });

        this.mostrar(mensaje);
    }

    listarNombresOrdenados() {
        let nombresOrdenados = this.usuarios
            .map(usuario => usuario.name)
            .sort();

        this.mostrar("Nombres ordenados alfabéticamente:\n" + nombresOrdenados.join("\n"));
    }
}

const admin = new AdministradorUsuarios();